<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- inner banner sec -->
<div class="interior-banner">
    <div class="interior-banner-slider owl-carousel owl-theme">
        <?php $__currentLoopData = $serviceBanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item banner-item">
                <a href="<?php echo e($banner->link); ?>"><img src="<?php echo e(asset('storage/' . $banner->image_path)); ?>" alt=""></a>
                <div class="banner-item-info">
                    
                    
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<!-- inner banner sec end  -->
<!-- services section -->
<section class="section-mt">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <?php echo $serviceDetails->description; ?>

            </div>
        </div>
    </div>
</section>
<?php if($serviceDetails->show_child_images == "0"){ ?>
<section>
    <div class="container">
        <div class="service_slider owl-carousel owl_navigation">
            <?php $__currentLoopData = $serviceSliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="service_box">
                    <a href="#">
                        <div class="holiday_pack_area">
                            <div class="service-pack-pic">
                                <img class="img-fluid" src="<?php echo e(asset('storage/' . $slider->image_path)); ?>"
                                    alt="<?php echo e($slider->name); ?>" />
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php }else{ ?>
<?php   foreach($serviceCatSliders as $catSlider){
                $categorySlider = $catSlider->servicecategoryimage;
        ?>


<?php } ?>
<?php } ?>
<!-- services section end -->
<section class="section-mb">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="form_wrapper">
                    <div class="form_container">
                        <div class="sec-title">
                            <h2>talk to our INTERIOFY experts</h2>
                        </div>
                            <?php if(Session::has('success')): ?>
                                <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('error')): ?>
                                <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
                                    <?php echo e(Session::get('error')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-area">
                                    <div class="form-inner">
                                        <form action="<?php echo e(route('storeEnquries')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('POST'); ?>
                                            <div class="form-group">
                                                <input type="text" name="fullName" class="form-control"
                                                    placeholder="First Name" value="" />
                                                <span class="text-danger">
                                                    <?php $__errorArgs = ['fullName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <strong><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </span>
                                            </div>
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Email"
                                                    name="email">
                                                <span class="text-danger">
                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <strong><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </span>
                                            </div>
                                            <div class="form-group">
                                                <input type="text" id="mobile_code" class="form-control"
                                                    placeholder="Phone Number" name="phoneNo">
                                                <span class="text-danger">
                                                    <?php $__errorArgs = ['phoneNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <strong><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </span>
                                            </div>
                                            <div class="form-group">
                                                <input type="text" class="form-control"
                                                    placeholder="Enter your current residence address with pincode"
                                                    name="address" />
                                                <span class="text-danger">
                                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <strong><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </span>
                                            </div>
                                            <button id="bfc" class="btn my_newBtn" type="submit">
                                                Submit
                                            </button>
                                            <p class="someText">By submitting this form, you agree to
                                                the <a class="turms_text" href="#">privacy policy</a>
                                                and <a class="turms_text" href="#"> terms of use </a>
                                            </p>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\Xampp\htdocs\interiofy\resources\views/servicesmenu/service-details.blade.php ENDPATH**/ ?>